"use client";
import { useState } from "react";
import Link from "next/link";
import Navbar from "../../../components/Navbar";
import { Avatar, Badges, TrustScore } from "../../../components/ui";
import { CURRENCY } from "../../../lib/brand";
import { activeJob, workers } from "../../../lib/mockData";
import ui from "../../../components/layout.module.css";
import styles from "./job.module.css";

const STEPS = ["Requested", "Accepted", "Worker arrived", "In progress", "Completed", "Paid & rated"];

export default function JobTracker() {
  const job = activeJob;
  const worker = workers.find((w) => w.id === job.workerId)!;
  const total = Math.round(worker.rate * job.hours * 1.05);

  const [step, setStep] = useState(3); // start the demo at "In progress"
  const [sosOpen, setSosOpen] = useState(false);
  const [sosSent, setSosSent] = useState(false);
  const [missedCheckIn, setMissedCheckIn] = useState(false);
  const [rating, setRating] = useState(0);

  const next = () => setStep((s) => Math.min(s + 1, STEPS.length - 1));

  return (
    <div className={ui.page}>
      <Navbar />
      <div className={ui.container}>
        <div className={styles.topRow}>
          <div>
            <span className={ui.muted}>Job #{job.id}</span>
            <h1 className={styles.title}>{job.title}</h1>
          </div>
          <button className={styles.sos} onClick={() => setSosOpen(true)}>
            SOS
          </button>
        </div>

        {sosSent && (
          <div className={styles.alertRed}>
            🚨 SOS sent. Your trusted contact and the safety team have your live location. Help is on the way.
          </div>
        )}
        {missedCheckIn && step < 4 && (
          <div className={styles.alertAmber}>
            ⏰ The job passed its scheduled end ({job.end}) + 30 min grace period without being closed. We&apos;ve
            messaged {worker.name.split(" ")[0]}&apos;s trusted contact and will escalate to the safety team in 15
            minutes.
          </div>
        )}

        <div className={ui.card}>
          <ol className={styles.steps}>
            {STEPS.map((s, i) => (
              <li key={s} className={i < step ? styles.done : i === step ? styles.current : styles.todo}>
                <span className={styles.dot}>{i < step ? "✓" : i + 1}</span>
                <span className={styles.stepLabel}>{s}</span>
              </li>
            ))}
          </ol>
        </div>

        <div className={`${ui.twoCol} ${styles.body}`}>
          <div>
            {step <= 3 && (
              <div className={ui.card}>
                <h2>{step === 3 ? "Job in progress" : STEPS[step]}</h2>
                <p className={styles.lead}>
                  Scheduled {job.start} – {job.end}. When the work is finished, confirm it here. If the job
                  isn&apos;t closed within 30 minutes of the end time, we automatically check on both of you.
                </p>
                <div className={styles.actions}>
                  <button className={ui.btn} onClick={() => setStep(4)}>
                    Confirm job is complete
                  </button>
                  <button className={ui.btnOutline} onClick={() => setMissedCheckIn(true)}>
                    Demo: simulate missed check-in
                  </button>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className={ui.card}>
                <h2>Pay {worker.name.split(" ")[0]}</h2>
                <p className={styles.lead}>
                  Payment method chosen: <strong>{job.payment}</strong>
                </p>
                <div className={styles.payBox}>
                  <div className={ui.row}>
                    <span>Account name</span>
                    <strong>{worker.name}</strong>
                  </div>
                  <div className={ui.row}>
                    <span>Bank</span>
                    <strong>NCB · ****4821</strong>
                  </div>
                  <div className={`${ui.row} ${ui.total}`}>
                    <span>Amount</span>
                    <span>
                      {CURRENCY}
                      {total.toLocaleString()}
                    </span>
                  </div>
                </div>
                <button className={ui.btn} onClick={next}>
                  I&apos;ve sent the transfer
                </button>
                <p className={styles.small}>{worker.name.split(" ")[0]} will confirm receipt in the app.</p>
              </div>
            )}

            {step === 5 && (
              <div className={ui.card}>
                <h2>Job closed. Rate {worker.name.split(" ")[0]}</h2>
                <div className={styles.rating}>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      className={n <= rating ? styles.starOn : styles.starOff}
                      onClick={() => setRating(n)}
                      aria-label={`${n} stars`}
                    >
                      ★
                    </button>
                  ))}
                </div>
                <textarea className={ui.input} placeholder="How did it go? (optional)" />
                <div className={styles.actions}>
                  <Link href="/" className={styles.linkBtn}>
                    Submit review
                  </Link>
                </div>
              </div>
            )}

            <div className={ui.card}>
              <h2>Details</h2>
              <div className={ui.row}>
                <span className={ui.muted}>Date</span>
                <span>{job.date}</span>
              </div>
              <div className={ui.row}>
                <span className={ui.muted}>Time</span>
                <span>
                  {job.start} – {job.end} ({job.hours} hrs)
                </span>
              </div>
              <div className={ui.row}>
                <span className={ui.muted}>Address</span>
                <span>{job.address}</span>
              </div>
              <div className={ui.row}>
                <span className={ui.muted}>Payment</span>
                <span>
                  {job.payment} on completion · {CURRENCY}
                  {total.toLocaleString()}
                </span>
              </div>
            </div>
          </div>

          <aside className={ui.card}>
            <div className={styles.workerTop}>
              <Avatar name={worker.name} size={56} />
              <div>
                <strong>{worker.name}</strong>
                <p className={ui.muted}>{worker.trade}</p>
              </div>
            </div>
            <div className={styles.workerMeta}>
              <Badges verification={worker.verification} />
              <TrustScore score={worker.trustScore} />
            </div>
            <div className={styles.checkin}>
              <strong>Check-ins</strong>
              <p>✓ Arrived 8:56 AM (location matched)</p>
              <p>✓ Started 9:02 AM</p>
              <p className={ui.muted}>Next: confirm completion by 1:30 PM</p>
            </div>
            <div className={styles.contactBtns}>
              <button className={ui.btnOutline}>💬 Message</button>
              <button className={ui.btnOutline}>📞 Call</button>
            </div>
          </aside>
        </div>
      </div>

      {sosOpen && (
        <div className={styles.overlay} onClick={() => setSosOpen(false)}>
          <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
            <div className={styles.sosBig}>SOS</div>
            <h2>Do you need help?</h2>
            <p className={ui.muted}>
              We&apos;ll share your live location with your trusted contact and our safety team.
            </p>
            <button
              className={styles.sosConfirm}
              onClick={() => {
                setSosSent(true);
                setSosOpen(false);
              }}
            >
              Send SOS alert
            </button>
            <a href="tel:119" className={styles.callPolice}>
              Call police (119)
            </a>
            <button className={styles.cancel} onClick={() => setSosOpen(false)}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
