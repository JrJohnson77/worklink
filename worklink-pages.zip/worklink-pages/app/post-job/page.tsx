"use client";
import { FormEvent, useState } from "react";
import Link from "next/link";
import Navbar from "../../components/Navbar";
import { Avatar, Badges, TrustScore } from "../../components/ui";
import { CURRENCY } from "../../lib/brand";
import { categories, locations, workers } from "../../lib/mockData";
import ui from "../../components/layout.module.css";
import styles from "./postjob.module.css";

const DURATIONS = ["One day", "Short-term (2-14 days)", "Long-term contract", "Recurring"];

export default function PostJob() {
  const [category, setCategory] = useState("Electrical");
  const [duration, setDuration] = useState(DURATIONS[0]);
  const [payment, setPayment] = useState("Cash");
  const [forSomeoneElse, setForSomeoneElse] = useState(false);
  const [posted, setPosted] = useState(false);

  // Mock "smart matching": same category first, then licensed workers, then highest trust score.
  const score = (w: (typeof workers)[number]) =>
    (w.category === category ? 1000 : 0) + (w.verification.includes("licensed") ? 100 : 0) + w.trustScore;
  const matches = [...workers].sort((a, b) => score(b) - score(a)).slice(0, 3);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setPosted(true);
    window.scrollTo({ top: 0 });
  }

  if (posted) {
    return (
      <div className={ui.page}>
        <Navbar />
        <div className={ui.container}>
          <div className={`${ui.card} ${styles.success}`}>
            <div className={styles.successIcon}>✓</div>
            <h1>Your job is live</h1>
            <p className={ui.muted}>
              We&apos;ve notified verified {category.toLowerCase()} workers nearby. Here are your best matches.
            </p>
          </div>
          <h2 className={styles.matchTitle}>Suggested matches</h2>
          <div className={styles.matches}>
            {matches.map((w, i) => (
              <div key={w.id} className={ui.card}>
                {i === 0 && <span className={styles.bestMatch}>Best match</span>}
                <div className={styles.matchTop}>
                  <Avatar name={w.name} />
                  <div>
                    <strong>{w.name}</strong>
                    <p className={ui.muted}>
                      {w.trade} · {w.location}
                    </p>
                  </div>
                </div>
                <div className={styles.matchMeta}>
                  <Badges verification={w.verification} />
                  <TrustScore score={w.trustScore} />
                </div>
                <Link href={`/workers/${w.id}`} className={styles.viewBtn}>
                  View &amp; book · {CURRENCY}
                  {w.rate.toLocaleString()}/hr
                </Link>
              </div>
            ))}
          </div>
          <button className={`${ui.btnOutline} ${styles.again}`} onClick={() => setPosted(false)}>
            Post another job
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={ui.page}>
      <Navbar />
      <div className={ui.container}>
        <h1 className={styles.title}>Post a job</h1>
        <p className={ui.muted}>Describe the work and we&apos;ll match you with verified workers.</p>
        <form className={ui.twoCol} onSubmit={handleSubmit}>
          <div>
            <div className={ui.card}>
              <h2>The job</h2>
              <div className={ui.field}>
                <label htmlFor="title">Job title</label>
                <input id="title" required className={ui.input} placeholder="e.g. Rewire kitchen outlets" />
              </div>
              <div className={ui.field}>
                <span className={ui.label}>Category</span>
                <div className={styles.catGrid}>
                  {categories.map((c) => (
                    <button
                      key={c.name}
                      type="button"
                      className={category === c.name ? ui.radioActive : ui.radio}
                      onClick={() => setCategory(c.name)}
                    >
                      {c.icon} {c.name}
                    </button>
                  ))}
                </div>
              </div>
              <div className={ui.field}>
                <label htmlFor="desc">Description</label>
                <textarea id="desc" className={ui.input} placeholder="What needs doing? Any tools or materials provided?" />
              </div>
            </div>

            <div className={ui.card}>
              <h2>When &amp; where</h2>
              <div className={ui.field}>
                <span className={ui.label}>Duration</span>
                <div className={styles.durationGrid}>
                  {DURATIONS.map((d) => (
                    <button
                      key={d}
                      type="button"
                      className={duration === d ? ui.radioActive : ui.radio}
                      onClick={() => setDuration(d)}
                    >
                      {d}
                    </button>
                  ))}
                </div>
              </div>
              <div className={styles.inline}>
                <div className={ui.field}>
                  <label htmlFor="date">Start date</label>
                  <input id="date" type="date" className={ui.input} defaultValue="2026-11-14" />
                </div>
                <div className={ui.field}>
                  <label htmlFor="loc">Location</label>
                  <select id="loc" className={ui.input}>
                    {locations.slice(1).map((l) => (
                      <option key={l}>{l}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className={ui.field}>
                <label htmlFor="addr">Address</label>
                <input id="addr" className={ui.input} placeholder="Shared with the worker only after you accept them" />
              </div>
            </div>
          </div>

          <aside>
            <div className={ui.card}>
              <h2>Budget &amp; payment</h2>
              <div className={ui.field}>
                <label htmlFor="budget">Budget ({CURRENCY})</label>
                <input id="budget" type="number" className={ui.input} placeholder="e.g. 15000" />
              </div>
              <div className={ui.field}>
                <span className={ui.label}>Pay on completion by</span>
                <div className={ui.radioGroup}>
                  {["Cash", "Bank transfer"].map((p) => (
                    <button
                      key={p}
                      type="button"
                      className={payment === p ? ui.radioActive : ui.radio}
                      onClick={() => setPayment(p)}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
              <label className={styles.check}>
                <input type="checkbox" checked={forSomeoneElse} onChange={(e) => setForSomeoneElse(e.target.checked)} />
                I&apos;m booking for someone else (e.g. a parent while I&apos;m abroad)
              </label>
              {forSomeoneElse && (
                <div className={ui.field}>
                  <label htmlFor="onsite">On-site contact</label>
                  <input id="onsite" className={ui.input} placeholder="Name and phone of person at the address" />
                </div>
              )}
            </div>
            <div className={`${ui.card} ${styles.safetyBox}`}>
              <strong>🛡 Safety built in</strong>
              <p>
                Address hidden until you accept a worker · Both sides get an SOS button · Automatic check-in if the
                job isn&apos;t closed on time
              </p>
            </div>
            <div className={styles.submit}>
              <button type="submit" className={ui.btn}>
                Post job &amp; find matches
              </button>
            </div>
          </aside>
        </form>
      </div>
    </div>
  );
}
