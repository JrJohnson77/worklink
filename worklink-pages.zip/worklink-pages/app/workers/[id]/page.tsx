"use client";
import { useState } from "react";
import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import Navbar from "../../../components/Navbar";
import { Avatar, Badges, Stars, TrustScore } from "../../../components/ui";
import { CURRENCY } from "../../../lib/brand";
import { workers } from "../../../lib/mockData";
import ui from "../../../components/layout.module.css";
import styles from "./worker.module.css";

export default function WorkerProfile() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const worker = workers.find((w) => w.id === id) ?? workers[0];

  const [hours, setHours] = useState(4);
  const [payment, setPayment] = useState("Bank transfer");
  const subtotal = worker.rate * hours;
  const fee = Math.round(subtotal * 0.05);

  // What the AI risk engine looked at to produce the trust score (mock values).
  const trustFactors = [
    { label: "Identity verified", ok: true },
    { label: "Licence / certificate checked", ok: worker.verification.includes("licensed") },
    { label: "No disputes in last 90 days", ok: true },
    { label: "Completes jobs on time", ok: worker.trustScore >= 90 },
  ];

  return (
    <div className={ui.page}>
      <Navbar />
      <div className={ui.container}>
        <Link href="/" className={ui.back}>
          ← Back to results
        </Link>
        <div className={ui.twoCol}>
          <div>
            <div className={ui.card}>
              <div className={styles.header}>
                <Avatar name={worker.name} size={72} />
                <div className={styles.headerInfo}>
                  <h1>{worker.name}</h1>
                  <p>
                    {worker.trade} · 📍 {worker.location}
                  </p>
                  <div className={styles.headerMeta}>
                    <Stars rating={worker.rating} />
                    <span className={ui.muted}>{worker.jobsDone} jobs completed</span>
                  </div>
                  <Badges verification={worker.verification} />
                </div>
              </div>
            </div>

            <div className={ui.card}>
              <h2>About</h2>
              <p className={styles.about}>{worker.about}</p>
              <div className={styles.skills}>
                {worker.skills.map((s) => (
                  <span key={s} className={styles.skill}>
                    {s}
                  </span>
                ))}
              </div>
            </div>

            <div className={ui.card}>
              <div className={styles.trustHeader}>
                <h2>Safety &amp; trust</h2>
                <TrustScore score={worker.trustScore} />
              </div>
              <p className={ui.muted}>
                The trust score is calculated by our AI risk engine from verification, job history and reports.
              </p>
              <ul className={styles.factors}>
                {trustFactors.map((f) => (
                  <li key={f.label} className={f.ok ? styles.factorOk : styles.factorNo}>
                    {f.ok ? "✓" : "–"} {f.label}
                  </li>
                ))}
              </ul>
            </div>

            <div className={ui.card}>
              <h2>Reviews</h2>
              {worker.reviews.map((r) => (
                <div key={r.author} className={styles.review}>
                  <div className={styles.reviewTop}>
                    <strong>{r.author}</strong>
                    <span>{"★".repeat(r.rating)}</span>
                  </div>
                  <p>{r.text}</p>
                </div>
              ))}
            </div>
          </div>

          <aside className={`${ui.card} ${styles.booking}`}>
            <h2>
              {CURRENCY}
              {worker.rate.toLocaleString()}
              <span className={ui.muted}> / hour</span>
            </h2>
            <div className={ui.field}>
              <label htmlFor="date">Date</label>
              <input id="date" type="date" className={ui.input} defaultValue="2026-11-14" />
            </div>
            <div className={styles.inline}>
              <div className={ui.field}>
                <label htmlFor="start">Start</label>
                <input id="start" type="time" className={ui.input} defaultValue="09:00" />
              </div>
              <div className={ui.field}>
                <label htmlFor="hours">Hours</label>
                <input
                  id="hours"
                  type="number"
                  min={1}
                  max={12}
                  className={ui.input}
                  value={hours}
                  onChange={(e) => setHours(Math.max(1, Number(e.target.value)))}
                />
              </div>
            </div>
            <div className={ui.field}>
              <span className={ui.label}>Pay on completion by</span>
              <div className={ui.radioGroup}>
                {["Cash", "Bank transfer"].map((p) => (
                  <button
                    key={p}
                    type="button"
                    className={payment === p ? ui.radioActive : ui.radio}
                    onClick={() => setPayment(p)}
                  >
                    {p === "Cash" ? "💵 " : "🏦 "}
                    {p}
                  </button>
                ))}
              </div>
            </div>
            <div className={ui.row}>
              <span>
                {CURRENCY}
                {worker.rate.toLocaleString()} × {hours} hrs
              </span>
              <span>
                {CURRENCY}
                {subtotal.toLocaleString()}
              </span>
            </div>
            <div className={ui.row}>
              <span>Service fee (5%)</span>
              <span>
                {CURRENCY}
                {fee.toLocaleString()}
              </span>
            </div>
            <div className={`${ui.row} ${ui.total}`}>
              <span>Total due after job</span>
              <span>
                {CURRENCY}
                {(subtotal + fee).toLocaleString()}
              </span>
            </div>
            <button className={`${ui.btn} ${styles.bookBtn}`} onClick={() => router.push("/jobs/1001")}>
              Request booking
            </button>
            <p className={styles.note}>You won&apos;t pay anything until you confirm the job is complete.</p>
          </aside>
        </div>
      </div>
    </div>
  );
}
