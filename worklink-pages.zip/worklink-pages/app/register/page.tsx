"use client";
import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { APP_NAME } from "../../lib/brand";
import { categories } from "../../lib/mockData";
import base from "../login/login.module.css";
import styles from "./register.module.css";

type Role = "hire" | "work";

const LICENSED_TRADES = ["Electrical", "Plumbing", "Auto Repair", "IT Support"];

export default function Register() {
  const router = useRouter();
  const [role, setRole] = useState<Role>("hire");
  const [accountType, setAccountType] = useState("individual");
  const [trade, setTrade] = useState("Gardening");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    router.push(role === "hire" ? "/" : "/jobs/1001");
  }

  return (
    <div className={base.page}>
      <form className={`${base.form} ${styles.wide}`} onSubmit={handleSubmit}>
        <div className={base.formHeader}>
          <div className={base.brand}>
            <span className={base.brandMark}>W</span>
            {APP_NAME}
          </div>
          <h1>Create your Account</h1>
          <p className={base.subtitle}>Every account is ID-verified before the first job.</p>
        </div>

        <div className={styles.roleToggle}>
          <button
            type="button"
            className={role === "hire" ? styles.roleActive : styles.role}
            onClick={() => setRole("hire")}
          >
            <strong>I want to hire</strong>
            <span>Find help for a day or a contract</span>
          </button>
          <button
            type="button"
            className={role === "work" ? styles.roleActive : styles.role}
            onClick={() => setRole("work")}
          >
            <strong>I want to work</strong>
            <span>Offer my skills and get booked</span>
          </button>
        </div>

        <div className={styles.grid}>
          <div className={styles.field}>
            <label htmlFor="first">First name</label>
            <input id="first" required className={styles.input} />
          </div>
          <div className={styles.field}>
            <label htmlFor="last">Last name</label>
            <input id="last" required className={styles.input} />
          </div>
          <div className={styles.field}>
            <label htmlFor="email">Email</label>
            <input id="email" type="email" required className={styles.input} />
          </div>
          <div className={styles.field}>
            <label htmlFor="phone">Phone</label>
            <input id="phone" type="tel" placeholder="+1 876 ..." required className={styles.input} />
          </div>
          <div className={`${styles.field} ${styles.full}`}>
            <label htmlFor="password">Password</label>
            <input id="password" type="password" required className={styles.input} />
          </div>

          {role === "hire" ? (
            <div className={`${styles.field} ${styles.full}`}>
              <label>Hiring as</label>
              <div className={styles.pills}>
                {[
                  ["individual", "Individual"],
                  ["business", "Business"],
                  ["abroad", "Family member abroad"],
                ].map(([value, label]) => (
                  <button
                    key={value}
                    type="button"
                    className={accountType === value ? styles.pillActive : styles.pill}
                    onClick={() => setAccountType(value)}
                  >
                    {label}
                  </button>
                ))}
              </div>
              {accountType === "business" && (
                <input placeholder="Business name / TRN" className={`${styles.input} ${styles.mt}`} />
              )}
            </div>
          ) : (
            <div className={`${styles.field} ${styles.full}`}>
              <label htmlFor="trade">Main trade</label>
              <select id="trade" className={styles.input} value={trade} onChange={(e) => setTrade(e.target.value)}>
                {categories.map((c) => (
                  <option key={c.name}>{c.name}</option>
                ))}
              </select>
              {LICENSED_TRADES.includes(trade) && (
                <p className={styles.notice}>
                  ★ {trade} is a regulated trade. You&apos;ll upload a licence or certificate for the
                  credential check after ID verification.
                </p>
              )}
            </div>
          )}

          <div className={`${styles.field} ${styles.full}`}>
            <label htmlFor="contact">Trusted contact (for safety check-ins)</label>
            <input id="contact" placeholder="Name and phone number" className={styles.input} />
          </div>
        </div>

        <label className={styles.terms}>
          <input type="checkbox" required /> I agree to the Terms and the Safety Policy
        </label>

        <div className={base.btnContainer}>
          <button type="submit" className={base.btn}>
            Continue to ID verification
          </button>
        </div>
        <p className={styles.footer}>
          Already have an account?{" "}
          <Link href="/login" className={base.link}>
            Sign in
          </Link>
        </p>
      </form>
    </div>
  );
}
