"use client";
import { FormEvent } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { APP_NAME } from "../../lib/brand";
import styles from "./login.module.css";

function AtIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1.2em" height="1.2em" viewBox="0 0 24 24">
      <title>at-fill</title>
      <path
        fill="none"
        stroke="currentColor"
        strokeLinecap="round"
        strokeWidth="3"
        d="m16.5 9l-.5 5c-.27 1.62 1 3 3 2c.5-.25 1.724-1.015 2-3.5C21.5 8 18 3 12 3a9 9 0 1 0 2.966 17.5M12.038 16C9.828 16 8 14.21 8 12s1.821-4 4.03-4c2.542 0 4.477 2.339 3.952 4.826c-.39 1.85-2.053 3.174-3.944 3.174Z"
      />
    </svg>
  );
}

function LockIcon() {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" width="1.2em" height="1.2em" viewBox="0 0 24 24">
      <title>lock</title>
      <path
        fill="currentColor"
        d="M6 22q-.825 0-1.412-.587T4 20V10q0-.825.588-1.412T6 8h1V6q0-2.075 1.463-3.537T12 1t3.538 1.463T17 6v2h1q.825 0 1.413.588T20 10v10q0 .825-.587 1.413T18 22zm7.413-5.587Q14 15.825 14 15t-.587-1.412T12 13t-1.412.588T10 15t.588 1.413T12 17t1.413-.587M9 8h6V6q0-1.25-.875-2.125T12 3t-2.125.875T9 6z"
      />
    </svg>
  );
}

export default function Login() {
  const router = useRouter();

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    // Mockup: no real auth yet, go straight to the browse page.
    router.push("/");
  }

  return (
    <div className={styles.page}>
      <form className={styles.form} onSubmit={handleSubmit}>
        <div className={styles.formHeader}>
          <div className={styles.brand}>
            <span className={styles.brandMark}>W</span>
            {APP_NAME}
          </div>
          <h1>Sign into your Account</h1>
          <p className={styles.subtitle}>Hire trusted workers or find your next job.</p>
        </div>
        <div className={styles.inputTopContainer}>
          <div className={styles.inputWrapper}>
            <label htmlFor="email">Enter your email</label>
            <input id="email" type="email" required className={styles.inputData} placeholder="you@example.com" />
            <div className={styles.domainSvg}>
              <AtIcon />
            </div>
          </div>
          <div className={styles.inputWrapper}>
            <label htmlFor="password">Enter your password</label>
            <input id="password" type="password" required className={styles.inputData} placeholder="••••••••" />
            <div className={styles.lockSvg}>
              <LockIcon />
            </div>
          </div>
        </div>
        <div className={styles.forgotRow}>
          <label className={styles.remember}>
            <input type="checkbox" /> Remember me
          </label>
          <Link href="/login" className={styles.link}>
            Forgot password?
          </Link>
        </div>
        <div className={styles.btnContainer}>
          <button type="submit" className={styles.btn}>
            Sign-in
          </button>
        </div>
        <div className={styles.divider}>
          <p>New to {APP_NAME}?</p>
        </div>
        {/* type="button" so this doesn't submit the sign-in form */}
        <button type="button" onClick={() => router.push("/register")} className={styles.createAccountBtn}>
          Create Account
        </button>
      </form>
    </div>
  );
}
