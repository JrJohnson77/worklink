"use client";
import { useMemo, useState } from "react";
import Link from "next/link";
import Navbar from "../components/Navbar";
import { Avatar, Badges, Stars, TrustScore } from "../components/ui";
import { CURRENCY } from "../lib/brand";
import { categories, locations, workers } from "../lib/mockData";
import styles from "./home.module.css";

export default function Home() {
  const [query, setQuery] = useState("");
  const [location, setLocation] = useState("All locations");
  const [category, setCategory] = useState<string | null>(null);
  const [verifiedOnly, setVerifiedOnly] = useState(false);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return workers.filter(
      (w) =>
        (!q || `${w.name} ${w.trade} ${w.skills.join(" ")}`.toLowerCase().includes(q)) &&
        (location === "All locations" || w.location === location) &&
        (!category || w.category === category) &&
        (!verifiedOnly || w.verification.includes("licensed"))
    );
  }, [query, location, category, verifiedOnly]);

  return (
    <div className={styles.page}>
      <Navbar />

      <section className={styles.hero}>
        <div className={styles.heroInner}>
          <h1>Hire trusted local help, by the hour, day or contract.</h1>
          <p>Verified workers, pay when the job is done, and safety check-ins on every booking.</p>
          <div className={styles.search}>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="What do you need done? e.g. fix a leak"
              className={styles.searchInput}
            />
            <select value={location} onChange={(e) => setLocation(e.target.value)} className={styles.searchSelect}>
              {locations.map((l) => (
                <option key={l}>{l}</option>
              ))}
            </select>
            <button className={styles.searchBtn}>Search</button>
          </div>
        </div>
      </section>

      <main className={styles.main}>
        <h2 className={styles.sectionTitle}>Browse by category</h2>
        <div className={styles.categories}>
          {categories.map((c) => (
            <button
              key={c.name}
              className={category === c.name ? styles.categoryActive : styles.category}
              onClick={() => setCategory(category === c.name ? null : c.name)}
            >
              <span className={styles.categoryIcon}>{c.icon}</span>
              {c.name}
            </button>
          ))}
        </div>

        <div className={styles.resultsHeader}>
          <h2 className={styles.sectionTitle}>
            {results.length} worker{results.length === 1 ? "" : "s"} available
            {category ? ` in ${category}` : ""}
          </h2>
          <label className={styles.toggle}>
            <input type="checkbox" checked={verifiedOnly} onChange={(e) => setVerifiedOnly(e.target.checked)} />
            Licensed trades only
          </label>
        </div>

        <div className={styles.grid}>
          {results.map((w) => (
            <Link key={w.id} href={`/workers/${w.id}`} className={styles.card}>
              <div className={styles.cardTop}>
                <Avatar name={w.name} />
                <div className={styles.cardInfo}>
                  <h3>{w.name}</h3>
                  <p>{w.trade}</p>
                  <p className={styles.muted}>📍 {w.location}</p>
                </div>
                <TrustScore score={w.trustScore} />
              </div>
              <Badges verification={w.verification} />
              <div className={styles.cardBottom}>
                <span>
                  <Stars rating={w.rating} /> <span className={styles.muted}>({w.jobsDone} jobs)</span>
                </span>
                <span className={styles.rate}>
                  {CURRENCY}
                  {w.rate.toLocaleString()}/hr
                </span>
              </div>
            </Link>
          ))}
          {results.length === 0 && <p className={styles.empty}>No workers match. Try another category or location.</p>}
        </div>

        <section className={styles.safety}>
          <div>
            <span className={styles.safetyIcon}>🪪</span>
            <h3>Verified profiles</h3>
            <p>ID checks for everyone, plus licence checks for electricians, plumbers and other regulated trades.</p>
          </div>
          <div>
            <span className={styles.safetyIcon}>💵</span>
            <h3>Pay on completion</h3>
            <p>Pay by cash or bank transfer only after you confirm the job is done.</p>
          </div>
          <div>
            <span className={styles.safetyIcon}>🆘</span>
            <h3>SOS &amp; check-ins</h3>
            <p>In-app SOS for both sides. If a job isn&apos;t closed on time, we alert a trusted contact.</p>
          </div>
        </section>
      </main>
    </div>
  );
}
