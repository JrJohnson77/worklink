"use client";
import Link from "next/link";
import { APP_NAME } from "../lib/brand";
import styles from "./Navbar.module.css";

export default function Navbar() {
  return (
    <header className={styles.nav}>
      <div className={styles.inner}>
        <Link href="/" className={styles.logo}>
          <span className={styles.logoMark}>W</span>
          {APP_NAME}
        </Link>
        <nav className={styles.links}>
          <Link href="/">Find workers</Link>
          <Link href="/post-job">Post a job</Link>
          <Link href="/jobs/1001">My jobs</Link>
        </nav>
        <div className={styles.actions}>
          <Link href="/login" className={styles.signIn}>
            Sign in
          </Link>
          <Link href="/register" className={styles.join}>
            Join
          </Link>
        </div>
      </div>
    </header>
  );
}
