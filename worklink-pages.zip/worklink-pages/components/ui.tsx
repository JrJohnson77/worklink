import styles from "./ui.module.css";
import type { Verification } from "../lib/mockData";

export function Avatar({ name, size = 48 }: { name: string; size?: number }) {
  const initials = name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("");
  return (
    <div className={styles.avatar} style={{ width: size, height: size, fontSize: size * 0.38 }}>
      {initials}
    </div>
  );
}

export function Badges({ verification }: { verification: Verification[] }) {
  return (
    <div className={styles.badges}>
      {verification.includes("id") && <span className={styles.badgeId}>✓ ID verified</span>}
      {verification.includes("licensed") && <span className={styles.badgeLicensed}>★ Licensed</span>}
    </div>
  );
}

export function TrustScore({ score }: { score: number }) {
  const level = score >= 90 ? styles.trustHigh : score >= 75 ? styles.trustMid : styles.trustLow;
  return <span className={`${styles.trust} ${level}`}>Trust {score}</span>;
}

export function Stars({ rating }: { rating: number }) {
  return (
    <span className={styles.stars}>
      ★ {rating.toFixed(1)}
    </span>
  );
}
