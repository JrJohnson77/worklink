// Mock data for the prototype. Replace with API calls later.

export type Verification = "id" | "licensed";

export type Worker = {
  id: string;
  name: string;
  trade: string;
  category: string;
  location: string;
  rating: number;
  jobsDone: number;
  rate: number; // per hour
  verification: Verification[];
  trustScore: number; // 0-100, from the AI risk engine
  about: string;
  skills: string[];
  reviews: { author: string; rating: number; text: string }[];
};

export const categories = [
  { name: "Gardening", icon: "🌿" },
  { name: "Plumbing", icon: "🔧" },
  { name: "Electrical", icon: "⚡" },
  { name: "IT Support", icon: "💻" },
  { name: "Auto Repair", icon: "🚗" },
  { name: "Cleaning", icon: "🧽" },
  { name: "Carpentry", icon: "🪚" },
  { name: "Moving", icon: "📦" },
];

export const locations = [
  "All locations",
  "Kingston",
  "St. Andrew",
  "St. Catherine",
  "Montego Bay",
  "Mandeville",
  "Ocho Rios",
];

export const workers: Worker[] = [
  {
    id: "1",
    name: "Andre Campbell",
    trade: "Licensed Electrician",
    category: "Electrical",
    location: "Kingston",
    rating: 4.9,
    jobsDone: 128,
    rate: 3500,
    verification: ["id", "licensed"],
    trustScore: 96,
    about:
      "Residential and commercial electrician with 9 years' experience. Panel upgrades, rewiring, lighting and fault finding.",
    skills: ["Rewiring", "Panel upgrades", "Lighting", "Fault finding"],
    reviews: [
      { author: "Simone R.", rating: 5, text: "On time, clean work, explained everything." },
      { author: "Blue Harbour Café", rating: 5, text: "We book Andre for all our maintenance now." },
    ],
  },
  {
    id: "2",
    name: "Kemar Brown",
    trade: "Gardener & Landscaper",
    category: "Gardening",
    location: "St. Andrew",
    rating: 4.7,
    jobsDone: 64,
    rate: 1500,
    verification: ["id"],
    trustScore: 91,
    about: "Lawn cutting, hedge trimming, yard clean-up and small landscaping jobs. Brings own tools.",
    skills: ["Lawn care", "Hedge trimming", "Yard clean-up"],
    reviews: [
      { author: "Mrs. Henry", rating: 5, text: "Yard looks brand new. Very respectful." },
      { author: "Paul D.", rating: 4, text: "Good job, came 20 minutes late." },
    ],
  },
  {
    id: "3",
    name: "Tanisha Reid",
    trade: "IT Support Technician",
    category: "IT Support",
    location: "St. Catherine",
    rating: 4.8,
    jobsDone: 87,
    rate: 3000,
    verification: ["id", "licensed"],
    trustScore: 94,
    about: "Network set-up, PC repair and small-business IT support. CompTIA A+ certified.",
    skills: ["Networking", "PC repair", "Wi-Fi set-up", "Backups"],
    reviews: [{ author: "Reid & Co. Law", rating: 5, text: "Fixed our office network in an afternoon." }],
  },
  {
    id: "4",
    name: "Dwayne Morgan",
    trade: "Plumber",
    category: "Plumbing",
    location: "Montego Bay",
    rating: 4.6,
    jobsDone: 52,
    rate: 2800,
    verification: ["id", "licensed"],
    trustScore: 89,
    about: "Leaks, pipe replacement, water heaters and bathroom fittings.",
    skills: ["Leak repair", "Water heaters", "Fixtures"],
    reviews: [{ author: "Kerry-Ann F.", rating: 5, text: "Found the leak fast. Fair price." }],
  },
  {
    id: "5",
    name: "Shanice Gordon",
    trade: "Home Cleaner",
    category: "Cleaning",
    location: "Kingston",
    rating: 4.9,
    jobsDone: 143,
    rate: 1200,
    verification: ["id"],
    trustScore: 97,
    about: "Deep cleans, move-in/move-out cleans and weekly housekeeping.",
    skills: ["Deep clean", "Move-out clean", "Laundry"],
    reviews: [{ author: "Marcia T. (booked from Toronto)", rating: 5, text: "Cleaned my mother's house while I was abroad. Sent photos after." }],
  },
  {
    id: "6",
    name: "Ricardo Thompson",
    trade: "Auto Mechanic",
    category: "Auto Repair",
    location: "Mandeville",
    rating: 4.5,
    jobsDone: 39,
    rate: 2500,
    verification: ["id"],
    trustScore: 86,
    about: "Mobile mechanic: servicing, brakes, diagnostics. I come to you.",
    skills: ["Servicing", "Brakes", "Diagnostics"],
    reviews: [{ author: "Jason L.", rating: 4, text: "Sorted my brakes at my gate. Recommended." }],
  },
];

export const activeJob = {
  id: "1001",
  title: "Rewire kitchen outlets",
  workerId: "1",
  address: "12 Hope Road, Kingston",
  date: "Sat, 14 Nov 2026",
  start: "9:00 AM",
  end: "1:00 PM",
  hours: 4,
  payment: "Bank transfer",
};
