// Change the name in one place once the group finalises it.
export const APP_NAME = "WorkLink";
export const CURRENCY = "J$";
